package com.example.easycalculator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

import java.util.Stack;


public class HomeActivity extends AppCompatActivity {
    LottieAnimationView anim1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animated);
        anim1 = findViewById(R.id.lottie1);
        anim1.setAnimation(R.raw.animate);
       new Handler().postDelayed(new Runnable() {
           @Override
           public void run() {
               Intent intent = new Intent(HomeActivity.this,MainActivity.class);
               startActivity(intent);
               finish();
           }
       },3000);
    }
}
